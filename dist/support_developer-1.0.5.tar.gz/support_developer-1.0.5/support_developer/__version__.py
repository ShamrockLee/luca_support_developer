"""Current version of package support_developer."""
__version__ = "1.0.5"