Support Developer
======================
|pip| |downloads|
Package designed to centralize messages to support developers development work.

I **personally** believe that open source developer should be compensated by the software users when
the users have the means. The support should be directly proportional to the amount of time the
software has spared to the user of the package.

For this reason, I have created this package that allows developers to show a cleanly designed banner,
exclusively to users working within **Jupyter Notebooks** so not to ruin script outputs, and exclusively
after they have been using the package for a given number of times.

Furthermore, this banner is only displayed if and only if **the user is importing the package directly**
in the Jupyter Notebook, and not as an import from a subpackage, so to avoid potential chains of banners
popping up.

I hope this solution is a valid and non-obnoxious option for allowing developers to be properly
compensated for their hard work, so many times taken for granted. Please feel free to
`open an issue <https://github.com/LucaCappelletti94/support_developer/issues>`_ or
`a pull repository <https://github.com/LucaCappelletti94/support_developer/pulls>`_ to discuss and improve this small idea.

Installing this package
------------------------------
As usual, to install this package you can simply use:

.. code:: shell

    pip install support_developer


Documentation
------------------------------
The code is all documented, but put briefly:

.. code:: python

    from support_developer import support_message

    support_message(
        package_name = "your_package_name",
        developer_name = "Your Name Here",
        github_handle = "YourGithubHandle",
        image_url = "http://www.website.org/image.png",
        repository_name = "repo_name_when_does_not_match_package_name",
        # Stack trace that should be met to display this object
        # in a Jupyter Notebook
        # Usually, this is either `2` or `3`, but it depends
        # how deep in your code you place this.
        # I generally just put this in the package init.
        expected_stack_trace_depth = 2,
        # After how many imports the user should see this banner.
        number_of_imports = (5, 100, 1000, 5000)
    )

The above code, when properly parametrized for my use case, will show you
the following banner. For instance, for the `silence_tensorflow package <https://github.com/LucaCappelletti94/silence_tensorflow>`_
a user will see:

|example|

.. |pip| image:: https://badge.fury.io/py/support-developer.svg
    :target: https://badge.fury.io/py/support-developer
    :alt: Pypi project

.. |downloads| image:: https://pepy.tech/badge/support-developer
    :target: https://pepy.tech/badge/support-developer
    :alt: Pypi total project downloads

.. |example| image:: https://github.com/LucaCappelletti94/support_developer/blob/main/example.png?raw=true
    :target: https://github.com/LucaCappelletti94/support_developer/blob/main/example.png
    :alt: Example
